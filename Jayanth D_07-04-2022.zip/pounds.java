package com.wipro.learn;

import java.util.Scanner;

public class pounds {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("calories burnt due to cycling ");
		int cyc = sc.nextInt();
		System.out.println("calories burnt due to Swiming");
		int swm = sc.nextInt();
		System.out.println("calories burnt due too running");
		int run = sc.nextInt();
		System.out.println("calories intake per day");
		int in = sc.nextInt();

		for (int i = 1; i <= 30; i++) {
			in = in + 100;

		}
		cyc=cyc*2*10;
		swm=swm*2*10;
		run=run*2*10;
		System.out.println("weight lost by anne in month is "+ (((cyc+swm+run)-in)/1000)+" pounds");
   	}

}
