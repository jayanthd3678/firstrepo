package com.wipro.learn;

import java.util.Scanner;

public class RevisedPrice {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the item name");
		String item = sc.nextLine();
		System.out.println("enter the selling price : $");
		Float SellingPrice =sc.nextFloat();
		System.out.println("revised selling price of "+item + " is $"+((SellingPrice)+(SellingPrice*0.05)));
		sc.close();
		
	}

}
