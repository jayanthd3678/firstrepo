package com.wipro.learn;
import java.util.Scanner;
public class WeightedAverageScore {

	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("assignment");
		float assignments =sc.nextFloat();
		System.out.println("project");
		float projects =sc.nextFloat();
		System.out.println("quizze");
		float quizzes =sc.nextFloat();
		System.out.println("midterms");
		float midterm =sc.nextFloat();
		System.out.println("finalexams");
		float finalexam =sc.nextFloat();
		System.out.println("assignment "+(assignments*0.1));
		System.out.println("project "+(projects*0.35));
		System.out.println("quizze "+(quizzes*0.1));
		System.out.println("midterms "+(midterm*0.15));
		System.out.println("finalexams "+(finalexam*0.3));
		System.out.println("overall percentage is "+((assignments*0.1)+(projects*0.35)+(quizzes*0.1)+(midterm*0.15)+(finalexam*0.3)));
		
	}

}
